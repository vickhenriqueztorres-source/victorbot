/**
 * B2Trading Multi-Chart Injected Engine (v2.1.0 - Zero-Dropout Edition)
 * =====================================================================
 * Executado diretamente no contexto da página (MAIN world).
 * Implementa Pure Passive Tap com telemetria forense de fechamento.
 */

(function () {
    if (window.__B2_MULTICHART_INJECTED__) return;
    window.__B2_MULTICHART_INJECTED__ = true;

    const C_SYS = "color: #00bbff; font-weight: bold;";
    const C_SYM = "color: #ffff00; font-weight: bold;";
    const C_GREEN = "color: #00ff88; font-weight: bold;";
    const C_RED = "color: #ff4444; font-weight: bold;";
    const C_WARN = "color: #ffaa00; font-weight: bold;";

    const assetEngines = new Map();
    const globalEvents = [];
    const activeSockets = new Set();
    const closeHistory = [];
    let wsConnectionsCount = 0;
    let lastGlobalWsMessageTime = Date.now();

    const WS_CLOSE_CODES = {
        1000: "Normal Closure (Encerramento normal pela aplicação)",
        1001: "Going Away (Página descarregada, recarregada ou aba fechada)",
        1002: "Protocol Error (Erro no protocolo WebSocket)",
        1003: "Unsupported Data (Tipo de dado incompatível)",
        1005: "No Status Received (Fechamento sem código de status)",
        1006: "Abnormal Closure (Queda abrupta sem handshake TCP/TLS - provável timeout de gateway, ausência de ping ou kill pelo servidor)",
        1007: "Invalid frame payload data (Dados inconsistentes com UTF-8)",
        1008: "Policy Violation (Violação de política: conexão duplicada, sessão substituída ou credencial inválida)",
        1009: "Message Too Big (Payload excedeu limite do servidor)",
        1011: "Internal Server Error (Erro interno no servidor da B2Trading)",
        1012: "Service Restart (Serviço da corretora reiniciando)",
        1013: "Try Again Later (Sobrecarga temporária no servidor)",
        1015: "TLS Handshake Failure (Falha na camada SSL/TLS)"
    };

    function explainCloseCode(code) {
        if (WS_CLOSE_CODES[code]) return WS_CLOSE_CODES[code];
        if (code >= 4000 && code <= 4999) return `Código customizado da B2Trading (${code})`;
        return `Código desconhecido (${code})`;
    }

    const NON_SYMBOL_WORDS = new Set([
        "TICKER", "TRADE", "TRADES", "QUOTES", "QUOTE", "CANDLE", "CANDLES",
        "BARS", "KLINE", "KLINES", "SUB", "UNSUB", "SUBSCRIBE", "UNSUBSCRIBE",
        "PING", "PONG", "SYSTEM", "DEFAULT", "STREAM", "MARKET", "DATA", "DEPTH",
        "ORDERBOOK", "STATUS", "AUTH", "LOGIN", "TOPIC", "CHANNEL", "EVENT",
        "UPDATE", "UPDATES", "SNAPSHOT", "INITIAL", "CONFIG", "ERROR", "RESPONSE",
        "REQUEST", "INFO", "HEARTBEAT", "SERVER", "CLIENT", "MESSAGE"
    ]);

    /**
     * =========================================================================
     * NÚCLEO QUANTITATIVO: INDICADORES E CONFLUÊNCIA SNIPER (70%+ ASSERTIVIDADE)
     * =========================================================================
     */

    function calculateEMA(values, period) {
        if (!values || values.length < 2) return null;
        const p = Math.min(period, values.length);
        const k = 2 / (p + 1);
        let ema = values[0];
        for (let i = 1; i < values.length; i++) {
            ema = values[i] * k + ema * (1 - k);
        }
        return ema;
    }

    function calculateRSI(closes, period = 7) {
        if (!closes || closes.length < period + 1) return 50;
        let gains = 0;
        let losses = 0;
        for (let i = 1; i <= period; i++) {
            const diff = closes[i] - closes[i - 1];
            if (diff >= 0) gains += diff;
            else losses -= diff;
        }
        let avgGain = gains / period;
        let avgLoss = losses / period;

        for (let i = period + 1; i < closes.length; i++) {
            const diff = closes[i] - closes[i - 1];
            const gain = diff > 0 ? diff : 0;
            const loss = diff < 0 ? -diff : 0;
            avgGain = (avgGain * (period - 1) + gain) / period;
            avgLoss = (avgLoss * (period - 1) + loss) / period;
        }

        if (avgLoss === 0) return 100;
        const rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }

    function calculateBollingerBands(closes, period = 20, mult = 2.2) {
        if (!closes || closes.length < Math.min(5, period)) return null;
        const effPeriod = Math.min(period, closes.length);
        const slice = closes.slice(-effPeriod);
        const mean = slice.reduce((a, b) => a + b, 0) / effPeriod;
        const variance = slice.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / effPeriod;
        const stdDev = Math.sqrt(variance);
        return {
            middle: mean,
            upper: mean + mult * stdDev,
            lower: mean - mult * stdDev,
            stdDev: stdDev
        };
    }

    function getCandleMetrics(candle) {
        const open = candle.open;
        const close = candle.close;
        const high = candle.high;
        const low = candle.low;
        const range = Math.max(high - low, 1e-6);
        const body = Math.abs(close - open);
        const upperWick = high - Math.max(open, close);
        const lowerWick = Math.min(open, close) - low;
        const isBull = close > open;
        const isBear = close < open;

        return {
            range,
            body,
            upperWick,
            lowerWick,
            bodyRatio: body / range,
            upperWickRatio: upperWick / range,
            lowerWickRatio: lowerWick / range,
            isBull,
            isBear
        };
    }

    function analyzeTickMicrostructure(ticks) {
        if (!Array.isArray(ticks) || ticks.length < 3) {
            return { valid: false, velocity: 0, delta: 0, vetoCall: false, vetoPut: false, favorableCall: false, favorablePut: false };
        }

        const lastTick = ticks[ticks.length - 1];
        const windowStart = lastTick.time - 10000;
        const recentTicks = ticks.filter(t => t.time >= windowStart);

        if (recentTicks.length < 2) {
            return { valid: false, velocity: 0, delta: 0, vetoCall: false, vetoPut: false, favorableCall: false, favorablePut: false };
        }

        const firstPrice = recentTicks[0].price;
        const finalPrice = recentTicks[recentTicks.length - 1].price;
        const delta = finalPrice - firstPrice;
        const dtSeconds = Math.max((recentTicks[recentTicks.length - 1].time - recentTicks[0].time) / 1000, 0.1);
        const velocity = delta / dtSeconds;

        let upTicks = 0;
        let downTicks = 0;
        for (let i = 1; i < recentTicks.length; i++) {
            if (recentTicks[i].price > recentTicks[i - 1].price) upTicks++;
            else if (recentTicks[i].price < recentTicks[i - 1].price) downTicks++;
        }

        const vetoCall = (delta < 0 && downTicks >= 3 && upTicks === 0);
        const vetoPut = (delta > 0 && upTicks >= 3 && downTicks === 0);

        return {
            valid: true,
            delta,
            velocity,
            upTicks,
            downTicks,
            vetoCall,
            vetoPut,
            favorableCall: delta > 0 && upTicks >= downTicks,
            favorablePut: delta < 0 && downTicks >= upTicks
        };
    }

    function evaluateSniperConfluence(candles, candleTicks) {
        if (!Array.isArray(candles) || candles.length < 5) {
            return {
                signal: "AGUARDAR",
                type: "HOLD",
                score: 0,
                confidence: 0,
                reasons: ["Histórico em aquecimento (mínimo 5 velas M1)"]
            };
        }

        const lastCandle = candles[candles.length - 1];
        const closes = candles.map(c => c.close);

        const rsi = calculateRSI(closes, 7);
        const bb = calculateBollingerBands(closes, 20, 2.2);
        const ema20 = calculateEMA(closes, 20);
        const ema100 = calculateEMA(closes, 100) || calculateEMA(closes, closes.length);
        const metrics = getCandleMetrics(lastCandle);
        const tickAnalysis = analyzeTickMicrostructure(candleTicks);

        let callScore = 0;
        const callReasons = [];

        let putScore = 0;
        const putReasons = [];

        // 1. REVERSÃO POR EXAUSTÃO & SWEEP INSTITUCIONAL (Alta assertividade OTC)
        if (bb && lastCandle.low <= bb.lower + 0.10 * bb.stdDev) {
            callScore += 25;
            callReasons.push(`Toque/Rompimento Banda Inferior (${bb.lower.toFixed(5)})`);
        }
        if (rsi <= 22) {
            const pts = rsi <= 15 ? 30 : 25;
            callScore += pts;
            callReasons.push(`RSI(7) Sobrevendido (${rsi.toFixed(1)})`);
        }
        if (metrics.lowerWickRatio >= 0.45 && metrics.bodyRatio <= 0.45) {
            callScore += 25;
            callReasons.push(`Pavio de Absorção Compradora (${(metrics.lowerWickRatio * 100).toFixed(0)}%)`);
        }
        if (ema20 && lastCandle.close >= ema20 * 0.998) {
            callScore += 10;
            callReasons.push("Suporte estrutural em consolidação");
        }

        if (bb && lastCandle.high >= bb.upper - 0.10 * bb.stdDev) {
            putScore += 25;
            putReasons.push(`Toque/Rompimento Banda Superior (${bb.upper.toFixed(5)})`);
        }
        if (rsi >= 78) {
            const pts = rsi >= 85 ? 30 : 25;
            putScore += pts;
            putReasons.push(`RSI(7) Sobrecomprado (${rsi.toFixed(1)})`);
        }
        if (metrics.upperWickRatio >= 0.45 && metrics.bodyRatio <= 0.45) {
            putScore += 25;
            putReasons.push(`Pavio de Rejeição Vendedora (${(metrics.upperWickRatio * 100).toFixed(0)}%)`);
        }
        if (ema20 && lastCandle.close <= ema20 * 1.002) {
            putScore += 10;
            putReasons.push("Resistência estrutural em consolidação");
        }

        // 2. IMPULSO DE TENDÊNCIA ESTRUTURAL
        if (ema20 && ema100) {
            if (ema20 > ema100 && metrics.isBull && metrics.bodyRatio >= 0.65 && metrics.upperWickRatio <= 0.15) {
                let trendCall = 35;
                const trendReasons = [
                    "Tendência de Alta Confirmada (EMA 20 > EMA 100)",
                    `Vela de Impulso Sólida (${(metrics.bodyRatio * 100).toFixed(0)}%)`
                ];
                if (rsi >= 52 && rsi <= 72) {
                    trendCall += 25;
                    trendReasons.push(`RSI(7) em Expansão (${rsi.toFixed(1)})`);
                }
                if (trendCall > callScore) {
                    callScore = trendCall;
                    callReasons.length = 0;
                    callReasons.push(...trendReasons);
                }
            }

            if (ema20 < ema100 && metrics.isBear && metrics.bodyRatio >= 0.65 && metrics.lowerWickRatio <= 0.15) {
                let trendPut = 35;
                const trendReasons = [
                    "Tendência de Baixa Confirmada (EMA 20 < EMA 100)",
                    `Vela de Impulso Sólida (${(metrics.bodyRatio * 100).toFixed(0)}%)`
                ];
                if (rsi >= 28 && rsi <= 48) {
                    trendPut += 25;
                    trendReasons.push(`RSI(7) em Expansão (${rsi.toFixed(1)})`);
                }
                if (trendPut > putScore) {
                    putScore = trendPut;
                    putReasons.length = 0;
                    putReasons.push(...trendReasons);
                }
            }
        }

        // 3. MICROESTRUTURA DE TICKS (:52s a :58s)
        if (tickAnalysis.valid) {
            if (callScore >= 50) {
                if (tickAnalysis.vetoCall) {
                    callScore -= 35;
                } else if (tickAnalysis.favorableCall) {
                    callScore += 15;
                    callReasons.push("Aceleração de Ticks Compradores nos segundos finais");
                }
            }
            if (putScore >= 50) {
                if (tickAnalysis.vetoPut) {
                    putScore -= 35;
                } else if (tickAnalysis.favorablePut) {
                    putScore += 15;
                    putReasons.push("Aceleração de Ticks Vendedores nos segundos finais");
                }
            }
        }

        // 4. GATILHO SNIPER (Score mínimo >= 75)
        const MIN_SNIPER_SCORE = 75;

        if (callScore >= MIN_SNIPER_SCORE && callScore > putScore) {
            const confidence = Math.min(92, Math.round(50 + callScore * 0.42));
            return {
                signal: `CALL (COMPRA) [SNIPER ${confidence}%]`,
                type: "CALL",
                score: callScore,
                confidence: confidence,
                reasons: callReasons,
                indicators: {
                    rsi: Number(rsi.toFixed(1)),
                    bb: bb ? { lower: Number(bb.lower.toFixed(5)), upper: Number(bb.upper.toFixed(5)) } : null,
                    ema20: ema20 ? Number(ema20.toFixed(5)) : null,
                    wickRatio: Number(metrics.lowerWickRatio.toFixed(2))
                }
            };
        } else if (putScore >= MIN_SNIPER_SCORE && putScore > callScore) {
            const confidence = Math.min(92, Math.round(50 + putScore * 0.42));
            return {
                signal: `PUT (VENDA) [SNIPER ${confidence}%]`,
                type: "PUT",
                score: putScore,
                confidence: confidence,
                reasons: putReasons,
                indicators: {
                    rsi: Number(rsi.toFixed(1)),
                    bb: bb ? { lower: Number(bb.lower.toFixed(5)), upper: Number(bb.upper.toFixed(5)) } : null,
                    ema20: ema20 ? Number(ema20.toFixed(5)) : null,
                    wickRatio: Number(metrics.upperWickRatio.toFixed(2))
                }
            };
        }

        return {
            signal: "AGUARDAR",
            type: "HOLD",
            score: Math.max(callScore, putScore),
            confidence: 0,
            reasons: ["Sem confluência suficiente para entrada segura (Score < 75)"],
            indicators: {
                rsi: Number(rsi.toFixed(1)),
                bb: bb ? { lower: Number(bb.lower.toFixed(5)), upper: Number(bb.upper.toFixed(5)) } : null,
                ema20: ema20 ? Number(ema20.toFixed(5)) : null
            }
        };
    }

    class AssetEngine {
        constructor(symbol, timeframeSec = 60) {
            this.symbol = String(symbol).toUpperCase().trim();
            this.timeframeSec = timeframeSec;
            this.timeframeMs = timeframeSec * 1000;
            this.status = "BOOTING";
            this.candles = [];
            this.currentCandle = null;
            this.candleTicks = [];
            this.tickCount = 0;
            this.lastTickTime = null;
            this.lastPrice = null;
            this.maxPrice = -Infinity;
            this.minPrice = Infinity;
            this.lastSignal = "AGUARDAR";
            this.lastSignalDetails = null;
            this.lastSignalTime = null;

            console.log(`%c[B2Engine] Nova Engine isolada criada: %c${this.symbol}%c (${this.timeframeSec}s)`, "color: #00bbff;", "color: #ffff00; font-weight: bold;", "color: #00bbff;");
            this.broadcast();
        }

        broadcast() {
            window.postMessage({
                source: "B2_ENGINE",
                type: "ASSET_UPDATE",
                data: this.getSnapshot()
            }, "*");
        }

        loadHistory(candlesArray) {
            if (!Array.isArray(candlesArray) || candlesArray.length === 0) return;

            const normalized = candlesArray.map(c => {
                let t = c.time || c.t || c[0];
                if (typeof t === "number" && t < 1e11) t *= 1000;
                return {
                    time: t,
                    open: Number(c.open !== undefined ? c.open : c.o !== undefined ? c.o : c[1]),
                    high: Number(c.high !== undefined ? c.high : c.h !== undefined ? c.h : c[2]),
                    low: Number(c.low !== undefined ? c.low : c.l !== undefined ? c.l : c[3]),
                    close: Number(c.close !== undefined ? c.close : c.c !== undefined ? c.c : c[4]),
                    volume: Number(c.volume !== undefined ? c.volume : c.v !== undefined ? c.v : c[5] || 0)
                };
            }).filter(c => !isNaN(c.close) && c.close > 0);

            if (normalized.length === 0) return;
            normalized.sort((a, b) => a.time - b.time);

            this.candles = normalized;
            this.status = "SYNCED";

            const lastC = this.candles[this.candles.length - 1];
            console.log(`%c[HISTORIAL] %c${this.candles.length} velas carregadas para ${this.symbol} (60s) | Fechamento anterior: ${lastC.close}`, "color: #00e5ff;", "color: #ffff00; font-weight: bold;");
            this.broadcast();
        }

        processTick(price, timestamp = Date.now()) {
            if (typeof price !== "number" || isNaN(price) || price <= 0) return;

            let ts = typeof timestamp === "number" ? timestamp : Date.now();
            if (ts < 1e11) ts *= 1000;

            this.tickCount++;
            this.lastPrice = price;
            this.lastTickTime = ts;

            const candleStartTime = Math.floor(ts / this.timeframeMs) * this.timeframeMs;

            if (!this.currentCandle || this.currentCandle.time !== candleStartTime) {
                if (this.currentCandle) {
                    this.finalizeCandle(this.currentCandle);
                }

                this.maxPrice = price;
                this.minPrice = price;
                this.candleTicks = [{ price, time: ts }];
                this.currentCandle = {
                    symbol: this.symbol,
                    time: candleStartTime,
                    open: price,
                    high: price,
                    low: price,
                    close: price,
                    volume: 0,
                    ticks: 1
                };

                console.log(`%c[STORE - ${this.symbol}] %cNueva vela abierta en ${this.symbol}. Abertura: ${price}`, "color: #ffaa00; font-weight: bold;", "color: #ffffff;");
            } else {
                this.currentCandle.close = price;
                this.currentCandle.ticks++;
                if (price > this.currentCandle.high) this.currentCandle.high = price;
                if (price < this.currentCandle.low) this.currentCandle.low = price;

                if (price > this.maxPrice) this.maxPrice = price;
                if (price < this.minPrice) this.minPrice = price;

                this.candleTicks.push({ price, time: ts });
                if (this.candleTicks.length > 200) this.candleTicks.shift();
            }

            if (this.tickCount % 10 === 1) {
                console.log(`%c[FEED - ${this.symbol}] %ctick: ${price.toFixed(5)} (máx: ${this.maxPrice.toFixed(5)}, mín: ${this.minPrice.toFixed(5)})`, "color: #88ff00;", "color: #cccccc;");
            }

            this.status = "RUNNING";
            this.broadcast();
        }

        finalizeCandle(candle) {
            const closedCandle = { ...candle };
            this.candles.push(closedCandle);
            if (this.candles.length > 500) this.candles.shift();

            // Avaliação Quantitativa Sniper Multicamadas
            const evaluation = evaluateSniperConfluence(this.candles, this.candleTicks);
            this.lastSignal = evaluation.signal;
            this.lastSignalDetails = evaluation;
            this.lastSignalTime = new Date().toLocaleTimeString();

            const isCompra = evaluation.signal.includes("COMPRA");
            const isVenda = evaluation.signal.includes("VENDA");
            const sigColor = isCompra ? "color: #00ff88; font-weight: bold;" : isVenda ? "color: #ff4444; font-weight: bold;" : "color: #ffaa00;";

            if (isCompra || isVenda) {
                console.log(
                    `%c[SINAL SNIPER - ${this.symbol}] %cVela Fechada: C=${closedCandle.close} | SINAL: %c${evaluation.signal} %c| Motivos: ${evaluation.reasons.join(", ")}`,
                    "color: #00ffff; font-weight: bold;",
                    "color: #ffffff;",
                    sigColor,
                    "color: #cccccc;"
                );
            } else {
                console.log(
                    `%c[FILTRO - ${this.symbol}] %cVela Fechada: C=${closedCandle.close} | Score Confluência: ${evaluation.score}/100 -> AGUARDAR`,
                    "color: #aaaaaa;",
                    "color: #777777;"
                );
            }

            globalEvents.push({
                type: "candle_closed",
                symbol: this.symbol,
                time: new Date(closedCandle.time).toISOString(),
                candle: closedCandle,
                signal: evaluation.signal,
                details: evaluation
            });

            this.broadcast();
        }

        getSnapshot() {
            return {
                symbol: this.symbol,
                status: this.status,
                lastPrice: this.lastPrice,
                minPrice: this.minPrice === Infinity ? null : this.minPrice,
                maxPrice: this.maxPrice === -Infinity ? null : this.maxPrice,
                tickCount: this.tickCount,
                historyLength: this.candles.length,
                currentCandle: this.currentCandle ? { ...this.currentCandle } : null,
                lastSignal: this.lastSignal,
                lastSignalDetails: this.lastSignalDetails,
                lastSignalTime: this.lastSignalTime
            };
        }
    }

    function getOrCreateEngine(rawSymbol) {
        if (!rawSymbol || typeof rawSymbol !== "string") return null;
        const clean = rawSymbol.toUpperCase().replace(/[^A-Z0-9_]/g, "").trim();
        if (!clean || clean.length < 3 || NON_SYMBOL_WORDS.has(clean)) return null;

        if (!assetEngines.has(clean)) {
            assetEngines.set(clean, new AssetEngine(clean, 60));
        }
        return assetEngines.get(clean);
    }

    function extractSymbol(msg) {
        if (!msg || typeof msg !== "object") return null;

        const direct = msg.symbol || msg.asset || msg.pair || msg.s || msg.instrument || msg.name || msg.market;
        if (direct && typeof direct === "string") {
            const clean = direct.toUpperCase().replace(/[^A-Z0-9_]/g, "");
            if (clean.length >= 3 && !NON_SYMBOL_WORDS.has(clean)) return clean;
        }

        const topic = msg.topic || msg.channel || msg.stream || msg.event;
        if (topic && typeof topic === "string") {
            const parts = topic.split(/[.:@/]/);
            for (const part of parts) {
                const clean = part.toUpperCase().replace(/[^A-Z0-9_]/g, "");
                if (clean.length >= 3 && !NON_SYMBOL_WORDS.has(clean)) {
                    return clean;
                }
            }
        }

        if (msg.data && typeof msg.data === "object") {
            const nested = extractSymbol(msg.data);
            if (nested) return nested;
        }
        if (msg.d && typeof msg.d === "object") {
            const nested = extractSymbol(msg.d);
            if (nested) return nested;
        }

        return null;
    }

    function extractPrice(msg) {
        if (!msg || typeof msg !== "object") return null;

        const candidates = [
            msg.price, msg.p, msg.close, msg.c, msg.last, msg.rate, msg.value, msg.val,
            msg.data?.price, msg.data?.p, msg.data?.close, msg.data?.c, msg.data?.rate,
            msg.d?.price, msg.d?.p, msg.d?.close
        ];

        for (const candidate of candidates) {
            if (candidate !== undefined && candidate !== null) {
                const num = Number(candidate);
                if (!isNaN(num) && num > 0) return num;
            }
        }
        return null;
    }

    function parseAndDispatchWsMessage(data) {
        try {
            let msg = null;
            if (typeof data === "string") {
                const trimmed = data.trim();
                if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                    msg = JSON.parse(trimmed);
                }
            } else if (typeof data === "object" && data !== null) {
                msg = data;
            }

            if (!msg) return;

            // Histórico getBars TradingView
            if (msg.s === "ok" && Array.isArray(msg.t) && Array.isArray(msg.c)) {
                const sym = extractSymbol(msg) || (msg.symbol ? String(msg.symbol) : null);
                if (sym) {
                    const engine = getOrCreateEngine(sym);
                    if (engine) {
                        const candles = msg.t.map((t, i) => ({
                            time: t * 1000,
                            open: msg.o ? msg.o[i] : msg.c[i],
                            high: msg.h ? msg.h[i] : msg.c[i],
                            low: msg.l ? msg.l[i] : msg.c[i],
                            close: msg.c[i],
                            volume: msg.v ? msg.v[i] : 0
                        }));
                        engine.loadHistory(candles);
                    }
                }
                return;
            }

            // Ticks em lote
            if (Array.isArray(msg)) {
                for (const item of msg) {
                    if (typeof item === "object" && item !== null) {
                        const sym = extractSymbol(item);
                        const price = extractPrice(item);
                        if (sym && price !== null) {
                            const engine = getOrCreateEngine(sym);
                            if (engine) engine.processTick(price, item.time || item.timestamp || Date.now());
                        }
                    }
                }
                return;
            }

            // Tick individual
            const sym = extractSymbol(msg);
            const price = extractPrice(msg);
            if (sym && price !== null) {
                const engine = getOrCreateEngine(sym);
                if (engine) {
                    const ts = msg.time || msg.timestamp || msg.t || msg.data?.time || msg.data?.t || Date.now();
                    engine.processTick(price, ts);
                }
            }
        } catch (e) {}
    }

    function hookWebSocketConstructor(targetWindow, label = "main") {
        if (!targetWindow || !targetWindow.WebSocket || targetWindow.__B2_TAP_INSTALLED__) return;
        targetWindow.__B2_TAP_INSTALLED__ = true;

        const NativeWS = targetWindow.WebSocket;
        const HookedWS = function (url, protocols) {
            const ws = new NativeWS(url, protocols);
            const urlClean = String(url).split("?")[0];
            const connectionId = ++wsConnectionsCount;
            activeSockets.add(ws);

            const connectTime = Date.now();
            console.log(`%c[WS PASSIVE TAP] Conexão oficial #${connectionId} interceptada (${urlClean}) [${label}]`, C_SYS);

            ws.addEventListener("message", function (e) {
                lastGlobalWsMessageTime = Date.now();
                parseAndDispatchWsMessage(e.data);
            });

            ws.addEventListener("close", function (e) {
                activeSockets.delete(ws);
                const durationSec = ((Date.now() - connectTime) / 1000).toFixed(1);
                const explanation = explainCloseCode(e.code);

                closeHistory.push({
                    connectionId: connectionId,
                    url: urlClean,
                    code: e.code,
                    reason: e.reason || "Sem motivo informado",
                    wasClean: e.wasClean,
                    durationSeconds: durationSec,
                    timestamp: new Date().toISOString()
                });

                console.warn(
                    `%c[WS TELEMETRIA] Conexão #${connectionId} fechada após ${durationSec}s | Código: ${e.code} (${explanation}) | Limpo: ${e.wasClean} | Motivo: "${e.reason || 'N/A'}"`,
                    "color: #ffaa00; font-weight: bold;"
                );

                if (e.code === 1008) {
                    console.error("%c[WS ALERTA] Código 1008 (Policy Violation): Sessão duplicada detectada! Feche outras abas ou scripts que possam estar usando o mesmo token.", "color: #ff4444; font-weight: bold;" );
                }
            });

            ws.addEventListener("error", function (err) {
                console.error(`%c[WS ERRO] Erro na conexão WebSocket #${connectionId} (${urlClean}):`, "color: #ff4444;", err);
            });

            const origSend = ws.send.bind(ws);
            ws.send = function (data) {
                try {
                    if (typeof data === "string") {
                        const sym = extractSymbol(JSON.parse(data));
                        if (sym) getOrCreateEngine(sym);
                    }
                } catch (err) {}
                return origSend(data);
            };

            return ws;
        };

        HookedWS.prototype = NativeWS.prototype;
        HookedWS.__B2_HOOKED__ = true;
        targetWindow.WebSocket = HookedWS;
    }

    function scanAndHookIframes() {
        if (typeof document === "undefined") return;
        const iframes = document.querySelectorAll("iframe");
        iframes.forEach((iframe, idx) => {
            try {
                const frameWin = iframe.contentWindow;
                if (!frameWin || frameWin.__B2_TAP_INSTALLED__) return;
                console.log(`%c[SISTEMA] Analisador ativo em iframe do gráfico #${idx + 1}`, C_GREEN);
                hookWebSocketConstructor(frameWin, `iframe-${idx + 1}`);
            } catch (e) {}
        });
    }

    hookWebSocketConstructor(window, "main");
    scanAndHookIframes();
    setInterval(scanAndHookIframes, 2000);

    window.addEventListener("message", (event) => {
        if (event.data && event.data.type === "B2_GET_STATUS_REQUEST") {
            const report = {};
            assetEngines.forEach((engine, sym) => {
                report[sym] = engine.getSnapshot();
            });
            window.postMessage({
                source: "B2_ENGINE",
                type: "B2_STATUS_RESPONSE",
                assets: report
            }, "*");
        }
    });

    window.b2engine = {
        status: function () {
            if (assetEngines.size === 0) {
                console.warn("[B2Engine] Nenhum ativo recebendo dados ainda.");
                return;
            }
            const report = {};
            assetEngines.forEach((engine, sym) => {
                report[sym] = {
                    "Estado": engine.status,
                    "Último Preço": engine.lastPrice || "--",
                    "Mín / Máx": engine.minPrice !== Infinity ? `${engine.minPrice} / ${engine.maxPrice}` : "--",
                    "Vela M1": engine.currentCandle ? `O:${engine.currentCandle.open} C:${engine.currentCandle.close}` : "--",
                    "Ticks": engine.tickCount,
                    "Histórico": engine.candles.length,
                    "Sinal": engine.lastSignal,
                    "Hora": engine.lastSignalTime || "--:--:--"
                };
            });
            console.table(report);
            return report;
        },
        telemetry: function () {
            const report = {
                "Conexões Ativas": activeSockets.size,
                "Total Histórico Conexões": wsConnectionsCount,
                "Quedas Registradas": closeHistory.length
            };
            console.table(report);
            if (closeHistory.length > 0) console.table(closeHistory);
            return report;
        },
        addAsset: getOrCreateEngine,
        getEngines: () => assetEngines
    };

    console.log("%c[✓] B2Trading Multi-Chart Injected Engine v2.1 Ativa! Use b2engine.status()", "color: #00ff88; font-weight: bold; font-size: 13px;");
})();
