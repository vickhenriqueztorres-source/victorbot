/**
 * Infiltrus Quant Sniper — B2Trading Popup Script
 * ===============================================
 * Gerencia renderização em tempo real dos sinais, estado psicológico da conta
 * (Demo vs VIP Real) e ações de conversão FTD (Primeiro Depósito).
 */

document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("assets-container");
    const btnRefresh = document.getElementById("btn-refresh");
    const btnExport = document.getElementById("btn-export");

    const badgeAccountStatus = document.getElementById("badge-account-status");
    const phantomCard = document.getElementById("phantom-card");
    const vipCard = document.getElementById("vip-card");

    const btnDepositPhantom = document.getElementById("btn-deposit-phantom");
    const btnDepositAction = document.getElementById("btn-deposit-action");
    const btnTelegramAction = document.getElementById("btn-telegram-action");

    const BROKER_URL = "https://b2trading.io/";
    const TELEGRAM_URL = "https://t.me/victorinfiltrustrader_bot";

    let currentAssets = {};

    // 1. Controle do Status Psicológico de Conta
    function updateAccountStatus(isVip) {
        if (isVip) {
            badgeAccountStatus.className = "badge-status badge-vip";
            badgeAccountStatus.textContent = "💎 STATUS VIP REAL: ACTIVADO";
            if (phantomCard) phantomCard.style.display = "none";
            if (vipCard) vipCard.style.display = "block";
        } else {
            badgeAccountStatus.className = "badge-status badge-demo";
            badgeAccountStatus.textContent = "🟡 LICENCIA DEMO: VENCE EN 48H";
            if (phantomCard) phantomCard.style.display = "block";
            if (vipCard) vipCard.style.display = "none";
        }
    }

    // 2. Links externos com chrome.tabs.create para máxima compatibilidade
    function openExternalUrl(url) {
        try {
            if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
                chrome.tabs.create({ url: url });
            } else {
                window.open(url, "_blank");
            }
        } catch (e) {
            window.open(url, "_blank");
        }
    }

    if (btnDepositPhantom) {
        btnDepositPhantom.addEventListener("click", (e) => {
            e.preventDefault();
            openExternalUrl(BROKER_URL);
        });
    }

    if (btnDepositAction) {
        btnDepositAction.addEventListener("click", (e) => {
            e.preventDefault();
            openExternalUrl(BROKER_URL);
        });
    }

    if (btnTelegramAction) {
        btnTelegramAction.addEventListener("click", (e) => {
            e.preventDefault();
            openExternalUrl(TELEGRAM_URL);
        });
    }

    // 3. Renderização dos cards dos gráficos monitorados
    function renderAssets(assets) {
        if (!assets || Object.keys(assets).length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    Buscando gráficos en la plataforma B2 Trading...<br>
                    Abre 2 o más gráficos en el traderoom para análisis simultáneo.
                </div>
            `;
            return;
        }

        container.innerHTML = "";

        Object.keys(assets).sort().forEach(sym => {
            const asset = assets[sym];
            const card = document.createElement("div");
            card.className = "asset-card";

            const sigClass = asset.lastSignal && asset.lastSignal.includes("COMPRA") ? "signal-compra" :
                             asset.lastSignal && asset.lastSignal.includes("VENDA") ? "signal-venda" : "signal-aguardar";

            const priceFormatted = typeof asset.lastPrice === "number" ? asset.lastPrice.toFixed(5) : "--";
            const minFormatted = typeof asset.minPrice === "number" ? asset.minPrice.toFixed(5) : "--";
            const maxFormatted = typeof asset.maxPrice === "number" ? asset.maxPrice.toFixed(5) : "--";

            const candleStr = asset.currentCandle ? 
                `O: ${Number(asset.currentCandle.open).toFixed(4)} | C: ${Number(asset.currentCandle.close).toFixed(4)}` : 
                "En formación...";

            card.innerHTML = `
                <div class="card-header">
                    <span class="card-symbol">${asset.symbol}</span>
                    <span class="card-status ${asset.status === 'RUNNING' ? 'status-running' : ''}">${asset.status}</span>
                </div>
                <div class="card-body">
                    <div class="metric-box">
                        <div class="metric-label">Último Precio</div>
                        <div class="metric-value">${priceFormatted}</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-label">Mín / Máx (M1)</div>
                        <div class="metric-value">${minFormatted} / ${maxFormatted}</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-label">Vela M1 Actual</div>
                        <div class="metric-value" style="font-size: 11px;">${candleStr}</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-label">Ticks / Historial</div>
                        <div class="metric-value">${asset.tickCount || 0} / ${asset.historyLength || 0} velas</div>
                    </div>
                </div>
                <div class="card-signal-row">
                    <div>
                        <span class="metric-label" style="display:block; margin-bottom:2px;">SEÑAL SNIPER (M1)</span>
                        <span class="signal-badge ${sigClass}">${asset.lastSignal || "AGUARDAR"}</span>
                    </div>
                    <div style="text-align: right;">
                        <span class="metric-label" style="display:block; margin-bottom:2px;">HORA</span>
                        <span class="signal-time">${asset.lastSignalTime || "--:--:--"}</span>
                    </div>
                </div>
                ${asset.lastSignalDetails && asset.lastSignalDetails.reasons && asset.lastSignalDetails.reasons.length > 0 ? `
                <div class="signal-reasons">
                    <strong>Confluencia:</strong> ${asset.lastSignalDetails.reasons.join(" • ")}
                </div>` : ""}
            `;

            container.appendChild(card);
        });
    }

    function loadState() {
        // Tenta buscar do storage local
        chrome.storage.local.get(["b2_assets", "infiltrus_license_type", "infiltrus_license"], (result) => {
            const isVip = result.infiltrus_license_type === "VIP" || (result.infiltrus_license && result.infiltrus_license.isVip);
            updateAccountStatus(isVip);

            if (result.b2_assets) {
                currentAssets = result.b2_assets;
                renderAssets(currentAssets);
            }
        });

        // Envia mensagem para a aba ativa
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].id) {
                chrome.tabs.sendMessage(tabs[0].id, { action: "GET_STATUS" }, (response) => {
                    if (response && response.assets) {
                        currentAssets = response.assets;
                        renderAssets(currentAssets);
                    }
                });
            }
        });
    }

    btnRefresh.addEventListener("click", loadState);

    btnExport.addEventListener("click", () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(currentAssets, null, 2));
        const downloadAnchor = document.createElement("a");
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", `infiltrus_multichart_export_${Date.now()}.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
    });

    loadState();
    setInterval(loadState, 1500);
});
