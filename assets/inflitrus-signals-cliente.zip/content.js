/**
 * B2Trading Multi-Chart Content Script & In-Traderoom Marketing HUD
 * =================================================================
 * Executa em todos os frames em document_start para injetar o injected.js.
 * No top-frame, injeta o HUD Flutuante de Conversão FTD ("Dinheiro Fantasma"),
 * o Interceptor de Vitórias (Toast de Dopamina no Ápice) e a Prova Social ao Vivo.
 */

// 1. Injeção imediata no DOM (MAIN world)
try {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("injected.js");
    script.onload = function () {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
} catch (err) {
    console.error("[B2Extension] Falha ao injetar script:", err);
}

// 2. Armazenamento em cache de ativos
let activeAssetsCache = {};
let sessionStats = {
    wins: 0,
    losses: 0,
    phantomProfit: 0.00,
    signalsCount: 0,
    isVip: false
};

const BROKER_DEPOSIT_URL = "https://b2trading.io/";
const TELEGRAM_URL = "https://t.me/victorinfiltrustrader_bot";

// 3. Prova Social Dinâmica ao Vivo (Eventos Rotativos)
const LIVE_SOCIAL_PROOF_FEED = [
    "🟢 Carlos R. (ID 849***) acaba de solicitar retiro de $38.20 USD vía Binance Pay",
    "💎 Marcos T. activó membresía VIP Real (60 Días) con depósito de $15",
    "🔥 152 operadores activos en la Sala Privada de B2 Trading",
    "🟢 Gabriel S. (ID 712***) retiró $54.00 USD por transferencia local",
    "🎯 Algoritmo Infiltrus: 4 entradas consecutivas en verde en sesión actual",
    "💎 Andrés M. desbloqueó configuración Sniper M1 sin ruido"
];
let socialProofIndex = 0;

// 4. Inicialização do HUD In-Traderoom (apenas no top-window)
if (window.top === window) {
    initInTraderoomMarketing();
}

function initInTraderoomMarketing() {
    // Carrega status da licença do storage
    try {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(["infiltrus_license_type", "infiltrus_license", "infiltrus_session_stats"], (res) => {
                if (res) {
                    if (res.infiltrus_license_type === "VIP" || (res.infiltrus_license && res.infiltrus_license.isVip)) {
                        sessionStats.isVip = true;
                    }
                    if (res.infiltrus_session_stats) {
                        sessionStats.wins = res.infiltrus_session_stats.wins || 0;
                        sessionStats.losses = res.infiltrus_session_stats.losses || 0;
                        sessionStats.phantomProfit = res.infiltrus_session_stats.phantomProfit || 0.00;
                        sessionStats.signalsCount = res.infiltrus_session_stats.signalsCount || 0;
                    }
                }
                injectHudWhenDomReady();
            });
        } else {
            injectHudWhenDomReady();
        }
    } catch (e) {
        injectHudWhenDomReady();
    }
}

function injectHudWhenDomReady() {
    if (document.body) {
        buildHudDom();
    } else {
        document.addEventListener("DOMContentLoaded", buildHudDom);
    }
}

function buildHudDom() {
    if (document.getElementById("infiltrus-hud-container")) return;

    // Injeta CSS com escopo isolado
    const style = document.createElement("style");
    style.id = "infiltrus-hud-styles";
    style.textContent = `
        #infiltrus-hud-container {
            position: fixed;
            top: 75px;
            right: 25px;
            z-index: 9999999;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            user-select: none;
        }
        .ifx-hud-card {
            width: 320px;
            background: linear-gradient(135deg, rgba(11, 16, 25, 0.96) 0%, rgba(15, 23, 42, 0.97) 100%);
            border: 1px solid rgba(56, 189, 248, 0.35);
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6), 0 0 15px rgba(56, 189, 248, 0.15);
            backdrop-filter: blur(12px);
            color: #f1f5f9;
            padding: 13px 15px;
            transition: all 0.25s ease;
        }
        .ifx-hud-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 8px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 9px;
            cursor: grab;
        }
        .ifx-hud-title {
            font-size: 13px;
            font-weight: 800;
            color: #38bdf8;
            display: flex;
            align-items: center;
            gap: 5px;
            letter-spacing: 0.3px;
        }
        .ifx-hud-controls {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .ifx-btn-toggle {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: #94a3b8;
            width: 20px;
            height: 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .ifx-btn-toggle:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
        }
        .ifx-badge-status {
            font-size: 9px;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 999px;
            letter-spacing: 0.4px;
            text-transform: uppercase;
        }
        .ifx-badge-demo {
            background: rgba(245, 185, 66, 0.15);
            color: #f5b942;
            border: 1px solid rgba(245, 185, 66, 0.4);
            box-shadow: 0 0 8px rgba(245, 185, 66, 0.2);
        }
        .ifx-badge-vip {
            background: rgba(0, 230, 118, 0.15);
            color: #00e676;
            border: 1px solid rgba(0, 230, 118, 0.4);
            box-shadow: 0 0 8px rgba(0, 230, 118, 0.2);
        }
        .ifx-stats-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(6, 11, 20, 0.65);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 7px;
            padding: 6px 10px;
            margin-bottom: 9px;
        }
        .ifx-stat-item {
            font-size: 10px;
            color: #94a3b8;
            font-weight: 600;
        }
        .ifx-stat-val-win {
            color: #00ff88;
            font-weight: 700;
        }
        .ifx-stat-val-loss {
            color: #ff5555;
            font-weight: 700;
        }
        .ifx-phantom-box {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.12) 0%, rgba(15, 23, 42, 0.7) 100%);
            border: 1px solid rgba(245, 158, 11, 0.35);
            border-radius: 8px;
            padding: 9px 11px;
            margin-bottom: 9px;
            text-align: center;
        }
        .ifx-phantom-label {
            font-size: 9px;
            font-weight: 700;
            color: #fbbf24;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 2px;
        }
        .ifx-phantom-amount {
            font-size: 19px;
            font-weight: 900;
            color: #00ff88;
            text-shadow: 0 0 12px rgba(0, 255, 136, 0.4);
            font-family: monospace;
            line-height: 1.2;
        }
        .ifx-phantom-sub {
            font-size: 9px;
            color: #94a3b8;
            margin-top: 3px;
            line-height: 1.3;
        }
        .ifx-phantom-sub em {
            color: #cbd5e1;
            font-style: normal;
            font-weight: 600;
        }
        .ifx-btn-deposit {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            width: 100%;
            background: linear-gradient(90deg, #10b981 0%, #059669 100%);
            color: #ffffff !important;
            text-decoration: none;
            font-size: 11px;
            font-weight: 800;
            padding: 8px 12px;
            border-radius: 6px;
            box-shadow: 0 3px 12px rgba(16, 185, 129, 0.35);
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.2s ease;
            box-sizing: border-box;
            text-align: center;
        }
        .ifx-btn-deposit:hover {
            filter: brightness(1.12);
            transform: scale(1.02);
            box-shadow: 0 5px 16px rgba(16, 185, 129, 0.5);
        }
        .ifx-soft-paywall-notice {
            background: rgba(239, 68, 68, 0.15);
            border: 1px dashed rgba(239, 68, 68, 0.4);
            border-radius: 6px;
            padding: 6px 8px;
            font-size: 9.5px;
            color: #fca5a5;
            margin-top: 7px;
            text-align: center;
            line-height: 1.35;
        }
        .ifx-social-ticker {
            font-size: 9px;
            color: #64748b;
            margin-top: 8px;
            padding-top: 6px;
            border-top: 1px dashed rgba(255, 255, 255, 0.08);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.3;
        }
        .ifx-hud-pill {
            display: none;
            background: rgba(11, 16, 25, 0.94);
            border: 1px solid rgba(56, 189, 248, 0.4);
            border-radius: 999px;
            padding: 6px 14px;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            color: #f8fafc;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            align-items: center;
            gap: 8px;
            transition: transform 0.2s;
        }
        .ifx-hud-pill:hover {
            transform: scale(1.03);
            border-color: #38bdf8;
        }
        .ifx-pill-amount {
            color: #00ff88;
            font-family: monospace;
        }

        /* 5. Interceptor de Vitórias (Toast de Dopamina no Ápice) */
        #ifx-win-toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 10000000;
            width: 330px;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(11, 16, 25, 0.98) 100%);
            border: 2px solid #10b981;
            border-radius: 12px;
            box-shadow: 0 10px 35px rgba(0, 0, 0, 0.7), 0 0 20px rgba(16, 185, 129, 0.4);
            backdrop-filter: blur(16px);
            padding: 14px 16px;
            color: #fff;
            transform: translateY(120%);
            opacity: 0;
            transition: all 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            pointer-events: none;
        }
        #ifx-win-toast.ifx-toast-show {
            transform: translateY(0);
            opacity: 1;
            pointer-events: auto;
        }
        .ifx-toast-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }
        .ifx-toast-badge {
            font-size: 11px;
            font-weight: 900;
            color: #00ff88;
            display: flex;
            align-items: center;
            gap: 6px;
            letter-spacing: 0.5px;
        }
        .ifx-toast-close {
            background: none;
            border: none;
            color: #94a3b8;
            font-size: 14px;
            cursor: pointer;
            padding: 2px 5px;
        }
        .ifx-toast-body {
            font-size: 11px;
            color: #e2e8f0;
            line-height: 1.45;
            margin-bottom: 10px;
        }
        .ifx-toast-gain {
            font-size: 14px;
            font-weight: 800;
            color: #00ff88;
            display: block;
            margin-bottom: 3px;
        }
    `;
    document.head.appendChild(style);

    // Constrói HTML do HUD
    const container = document.createElement("div");
    container.id = "infiltrus-hud-container";
    container.innerHTML = `
        <div class="ifx-hud-card" id="ifx-card">
            <div class="ifx-hud-header" id="ifx-header">
                <div class="ifx-hud-title">
                    <span>🎯</span> INFILTRUS QUANT
                </div>
                <div class="ifx-hud-controls">
                    <span id="ifx-badge" class="ifx-badge-status ${sessionStats.isVip ? 'ifx-badge-vip' : 'ifx-badge-demo'}">
                        ${sessionStats.isVip ? '💎 VIP REAL' : '🟡 DEMO 48H'}
                    </span>
                    <button class="ifx-btn-toggle" id="ifx-btn-collapse" title="Minimizar">_</button>
                </div>
            </div>

            <div class="ifx-stats-row">
                <span class="ifx-stat-item">Sesión Actual:</span>
                <span class="ifx-stat-item">
                    <span class="ifx-stat-val-win" id="ifx-wins">🟢 ${sessionStats.wins} WIN</span> | 
                    <span class="ifx-stat-val-loss" id="ifx-losses">🔴 ${sessionStats.losses} LOSS</span>
                </span>
            </div>

            ${!sessionStats.isVip ? `
            <div class="ifx-phantom-box" id="ifx-phantom-box">
                <div class="ifx-phantom-label">GANANCIA ESTIMADA DEMO</div>
                <div class="ifx-phantom-amount" id="ifx-amount">+$${sessionStats.phantomProfit.toFixed(2)} USD</div>
                <div class="ifx-phantom-sub">
                    <em>Dinero de fantasía.</em> En Cuenta Real ya estaría disponible para retiro a tu cuenta.
                </div>
            </div>
            <a href="${BROKER_DEPOSIT_URL}" target="_blank" class="ifx-btn-deposit" id="ifx-btn-deposit-hud">
                🚀 Depositar $15 USD y Activar VIP 60D
            </a>
            <div class="ifx-soft-paywall-notice" id="ifx-soft-notice" style="display: ${sessionStats.signalsCount >= 4 ? 'block' : 'none'};">
                ${sessionStats.signalsCount >= 5 ? 
                    '🔒 <b>Cota de señales Demo alcanzada (5/5).</b> Para señales ilimitadas sin delay, activa tu Cuenta Real ($15 USD).' : 
                    '⚠️ <b>Atención:</b> Te queda 1 señal demo de cortesía en esta sesión.'}
            </div>
            ` : `
            <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 7px; padding: 8px 10px; margin-bottom: 8px; text-align: center;">
                <div style="font-size: 10px; font-weight: 700; color: #00ff88;">VENTAJA CUENTA REAL ACTIVA</div>
                <div style="font-size: 9px; color: #94a3b8; margin-top: 2px;">Filtros de Máxima Asertividad M1 & Gestión 2x1 Blindada.</div>
            </div>
            `}

            <div class="ifx-social-ticker" id="ifx-ticker">
                ${LIVE_SOCIAL_PROOF_FEED[0]}
            </div>
        </div>

        <div class="ifx-hud-pill" id="ifx-pill">
            <span>🎯 Infiltrus:</span>
            <span class="ifx-pill-amount" id="ifx-pill-amount">+$${sessionStats.phantomProfit.toFixed(2)} Demo</span>
            <span style="font-size: 10px; color: #94a3b8;" id="ifx-pill-score">(${sessionStats.wins}W-${sessionStats.losses}L)</span>
            <span style="color: #00ff88; font-size: 10px;">[Abrir]</span>
        </div>
    `;

    document.body.appendChild(container);

    // Toast do Interceptor de Vitórias
    const toast = document.createElement("div");
    toast.id = "ifx-win-toast";
    toast.innerHTML = `
        <div class="ifx-toast-header">
            <span class="ifx-toast-badge">🏆 🎯 ¡OPERACIÓN GANADORA!</span>
            <button class="ifx-toast-close" id="ifx-toast-close">✕</button>
        </div>
        <div class="ifx-toast-body">
            <span class="ifx-toast-gain">+$8.50 USD generados en Cuenta Demo</span>
            Sentir la victoria es bueno, pero retirarla a tu banco es mejor. ¿Listo para operar en Real con $15?
        </div>
        <a href="${BROKER_DEPOSIT_URL}" target="_blank" class="ifx-btn-deposit" id="ifx-btn-toast-deposit">
            🚀 Activar Cuenta Real ($15 USD)
        </a>
    `;
    document.body.appendChild(toast);

    // Configura eventos de clique e minimização
    setupHudEvents(container, toast);

    // Inicia rotação da prova social
    setInterval(rotateSocialProof, 11000);
}

function setupHudEvents(container, toast) {
    const card = container.querySelector("#ifx-card");
    const pill = container.querySelector("#ifx-pill");
    const btnCollapse = container.querySelector("#ifx-btn-collapse");
    const toastClose = toast.querySelector("#ifx-toast-close");

    if (btnCollapse) {
        btnCollapse.addEventListener("click", () => {
            card.style.display = "none";
            pill.style.display = "flex";
        });
    }

    if (pill) {
        pill.addEventListener("click", () => {
            pill.style.display = "none";
            card.style.display = "block";
        });
    }

    if (toastClose) {
        toastClose.addEventListener("click", () => {
            toast.classList.remove("ifx-toast-show");
        });
    }
}

function rotateSocialProof() {
    const ticker = document.getElementById("ifx-ticker");
    if (!ticker) return;
    socialProofIndex = (socialProofIndex + 1) % LIVE_SOCIAL_PROOF_FEED.length;
    ticker.textContent = LIVE_SOCIAL_PROOF_FEED[socialProofIndex];
}

function triggerWinInterceptorToast(profitGained = 8.50) {
    const toast = document.getElementById("ifx-win-toast");
    if (!toast) return;

    const gainEl = toast.querySelector(".ifx-toast-gain");
    if (gainEl) {
        gainEl.textContent = `+$${profitGained.toFixed(2)} USD generados en Cuenta Demo`;
    }

    toast.classList.add("ifx-toast-show");

    // Auto-fecha após 8.5 segundos
    setTimeout(() => {
        toast.classList.remove("ifx-toast-show");
    }, 8500);
}

function updateHudStats() {
    const winsEl = document.getElementById("ifx-wins");
    const lossesEl = document.getElementById("ifx-losses");
    const amountEl = document.getElementById("ifx-amount");
    const pillAmountEl = document.getElementById("ifx-pill-amount");
    const pillScoreEl = document.getElementById("ifx-pill-score");
    const softNoticeEl = document.getElementById("ifx-soft-notice");

    if (winsEl) winsEl.textContent = `🟢 ${sessionStats.wins} WIN`;
    if (lossesEl) lossesEl.textContent = `🔴 ${sessionStats.losses} LOSS`;
    if (amountEl) amountEl.textContent = `+$${sessionStats.phantomProfit.toFixed(2)} USD`;
    if (pillAmountEl) pillAmountEl.textContent = `+$${sessionStats.phantomProfit.toFixed(2)} Demo`;
    if (pillScoreEl) pillScoreEl.textContent = `(${sessionStats.wins}W-${sessionStats.losses}L)`;

    if (softNoticeEl && !sessionStats.isVip) {
        if (sessionStats.signalsCount >= 5) {
            softNoticeEl.style.display = "block";
            softNoticeEl.innerHTML = "🔒 <b>Cota Demo Alcanzada (5/5).</b> Para señales ilimitadas sin delay, activa tu Cuenta Real ($15 USD).";
        } else if (sessionStats.signalsCount >= 4) {
            softNoticeEl.style.display = "block";
            softNoticeEl.innerHTML = "⚠️ <b>Atención:</b> Te queda 1 señal demo de cortesía en esta sesión.";
        }
    }

    // Salva estado da sessão
    try {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ infiltrus_session_stats: sessionStats });
        }
    } catch (e) {}
}

// 5. Escuta mensagens vindas do injected.js
window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.source !== "B2_ENGINE") return;

    if (event.data.type === "ASSET_UPDATE" && event.data.data) {
        const asset = event.data.data;
        activeAssetsCache[asset.symbol] = asset;
        try {
            chrome.storage.local.set({ b2_assets: activeAssetsCache });
        } catch (e) {}
    } else if (event.data.type === "B2_STATUS_RESPONSE" && event.data.assets) {
        activeAssetsCache = event.data.assets;
        try {
            chrome.storage.local.set({ b2_assets: activeAssetsCache });
        } catch (e) {}
    } else if (event.data.type === "SNIPER_SIGNAL_GENERATED" && event.data.data) {
        sessionStats.signalsCount++;
        updateHudStats();
    } else if (event.data.type === "SNIPER_SIGNAL_RESULT" && event.data.data) {
        const res = event.data.data;
        if (res.result === "WIN") {
            sessionStats.wins++;
            sessionStats.phantomProfit += (res.profitUsd || 8.50);
            updateHudStats();
            triggerWinInterceptorToast(res.profitUsd || 8.50);
        } else if (res.result === "LOSS") {
            sessionStats.losses++;
            updateHudStats();
        }
    }
});

// 6. Responde a mensagens vindas do popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_STATUS") {
        window.postMessage({ type: "B2_GET_STATUS_REQUEST" }, "*");
        sendResponse({ success: true, assets: activeAssetsCache, stats: sessionStats });
    }
    return true;
});
