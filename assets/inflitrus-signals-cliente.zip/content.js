/**
 * B2Trading Multi-Chart Content Script
 * ====================================
 * Executa em todos os frames em document_start para injetar o injected.js
 * no contexto da página e intermediar o estado com a popup da extensão.
 */

// Injeção imediata no DOM (MAIN world)
try {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("injected.js");
    script.onload = function () {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
} catch (err) {
    console.error("[B2Extension] Falha ao injetar script:", err);
}

// Armazenamento em cache de ativos
let activeAssetsCache = {};

// Escuta mensagens vindas do injected.js
window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.source !== "B2_ENGINE") return;

    if (event.data.type === "ASSET_UPDATE" && event.data.data) {
        const asset = event.data.data;
        activeAssetsCache[asset.symbol] = asset;
        try {
            chrome.storage.local.set({ b2_assets: activeAssetsCache });
        } catch (e) {}
    } else if (event.data.type === "B2_STATUS_RESPONSE" && event.data.assets) {
        activeAssetsCache = event.data.assets;
        try {
            chrome.storage.local.set({ b2_assets: activeAssetsCache });
        } catch (e) {}
    }
});

// Responde a mensagens vindas do popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_STATUS") {
        window.postMessage({ type: "B2_GET_STATUS_REQUEST" }, "*");
        sendResponse({ success: true, assets: activeAssetsCache });
    }
    return true;
});
